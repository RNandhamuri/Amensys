package test;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GmailVerifyLogin {
	public static void main(String[] args) {
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.gmail.com// ");
		driver.manage().window().maximize();
		driver.findElement(By.id("Email")).sendKeys("ravalichowdhary10@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("Next")).click();
		//System.out.println("ravali");
		driver.findElement(By.id("Password")).sendKeys("Password");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("signIn")).click();
		driver.findElement(By.xpath("//divss='z0']/div")).click();
		// Click on the image icon present in the top right navigational Bar
		driver.findElement(By.xpath("//divss='gb_1 gb_3a gb_nc gb_e']/div/a")).click();
		//Click on 'Logout' Button
		driver.findElement(By.xpath("//*[@id='gb_71']")).click();
		//Close the browser.
		driver.close();

	}

}
