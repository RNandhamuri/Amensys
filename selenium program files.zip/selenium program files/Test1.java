package test;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Test1 {
	@Test
	public void create_account(){
		
			WebDriver driver = new FirefoxDriver();
			driver.get("https://www.facebook.com/");
			String pageTitle = driver.getTitle();
			Assert.assertEquals(pageTitle, "Facebook - Log In or Sign Up");
			
			WebElement Firstname = driver.findElement(By.xpath(".//*[@id='u_0_1']"));
			Firstname.sendKeys("Ravali");
		
			WebElement Lastname = driver.findElement(By.xpath(".//*[@id='u_0_3']"));
			Lastname.sendKeys("Nandhamuri");
			
			WebElement phno = driver.findElement(By.xpath(".//*[@id='u_0_8']"));
			phno.sendKeys("8325032370");
								
			WebElement passwd =driver.findElement(By.xpath(".//*[@id='u_0_f']"));
			passwd.sendKeys("Ravali@123");
			Select dropDown = new Select (driver.findElement(By.name("birthday_month")));
			dropDown.selectByIndex(7);
			dropDown.selectByVisibleText("Jul");
			Select dropDown1 = new Select (driver.findElement(By.name("birthday_day")));
			dropDown1.selectByIndex(7);
			dropDown1.selectByValue("7");
		    Select dropDown2 = new Select (driver.findElement(By.name("birthday_year")));
			dropDown2.selectByIndex(7);
			dropDown2.selectByValue("2012");
			WebElement maleRadioButton = driver.findElement(By.xpath(".//*[@id='u_0_i']"));
			boolean elementStatus = maleRadioButton.isDisplayed();
			System.out.println(elementStatus);//true
			
			maleRadioButton.click();
			driver.findElement(By.cssSelector("#u_0_e")).click();
			driver.close();
}
}
