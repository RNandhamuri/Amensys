package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class VerifyLogin {
	public static void main(String[] args) {

		WebDriver driver = new FirefoxDriver();

		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.findElement(By.id("email")).sendKeys("ravalichowdhary10@gmail.com");
		driver.findElement(By.id("pass")).sendKeys("3010#Kanna");
		driver.findElement(By.id("u_0_u")).click();

			}
}
