package callingmethodwithnoreturnandparameter;

public class Apple1 {
	Apple1()//creating constructor with no parameters
	{
	System.out.println("Apple is created");}  
	public static void main(String args[]){  
	Apple1 a=new Apple1();  //creation of object
	}  

}
