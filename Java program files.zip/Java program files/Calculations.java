package com.AdditionSample;

public class Calculations {
	public static void main(String[] args) {
		double girls, boys, people;
		girls = 5;
		boys = 4;
		people = girls * boys;
		System.out.println(people);

	}
}
