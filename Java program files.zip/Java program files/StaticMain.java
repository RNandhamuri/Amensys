package com.Keywords;

public class StaticMain {
	public static void main(String[] args) {
		StaticMain sample=new StaticMain();
		StaticMain sample1=new StaticMain();
		StaticMain sample2=new StaticMain();
		System.out.println(sample);
		System.out.println(sample1);
		System.out.println(sample2);
	}
}
