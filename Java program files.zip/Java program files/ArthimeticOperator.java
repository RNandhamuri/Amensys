package com.Operators;
public class ArthimeticOperator {
	public static void main(String[] args) {
		int i = 5;
        int j = 10;
        i += 5; 
        j -= 2; 
        System.out.println("i = " + i);
        System.out.println("j = " + j);
     }
}
