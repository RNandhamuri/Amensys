package com.Inheritance;

public class Else {
	public static void main(String[] args) {
		int age = 45;
		if(age>=50){
			System.out.println("you are a senior citizen");}
		else if(age<=30){
			System.out.println("you are too young");
		}
		else if(age>=40){
			System.out.println("you are dashing");}
		}
	}



