package com.Operators;

public class IncrementDecrement {
	 public static void main(String[] args) {
          int i = 10;
          int j = 10;
          i++;
          j++;
          System.out.println("i = " + i);
          System.out.println("j = " + j);
	 }  
}
