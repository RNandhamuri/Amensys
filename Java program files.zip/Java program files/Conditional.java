package com.Inheritance;

public class Conditional {
	public static void main(String[] args) {
		int age=45;
		System.out.println(age>50? " you are old" : " you are not old");
		
	}
}
