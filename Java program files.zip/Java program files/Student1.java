package createstaticproperty;

public class Student1 {
	int rollno;  
    String name;  
    static String college = "HITS";  
     
    static void change(){  // creating static method
    college = "KITS";  
    }  
 
   Student1(int r, String n){ //creating constructor 
    rollno = r;  
   name = n;  
 }  
 //creating method name display
   void display (){
System.out.println(rollno+" "+name+" "+college);}  

  public static void main(String args[]){  
   Student1.change();  
 //creating objects
   Student1 s1 = new Student1 (111,"Ravali");  
  Student1 s2 = new Student1 (222,"Ball");  
  Student1 s3 = new Student1 (333,"Prasanthi");  
 
  s1.display();  //calling method 
  s2.display();  
   s3.display();  
   }  

}
