package com.Inheritance;

public class Arrays {
	public static void main(String[] args) {
		int sanju[]={2,4,6,9,3,4,4,6,8};
		System.out.println(sanju[4]);
		
		
	}

}
