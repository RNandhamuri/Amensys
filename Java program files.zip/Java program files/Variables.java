package com.DataTypes;

public class Variables {
	public static void main(String[] args) {
		double tuna;
		double $a;
		$a=10;
		int count = 10;
		tuna = 5;
		System.out.print("I want ");
		System.out.print(tuna);
		System.out.println(" apples");
		System.out.println(" I want " + tuna + " apples " + tuna + "Ravali");
		System.out.println("Ravali has " + count + " apples ");
		System.out.println( $a );
	}
}
