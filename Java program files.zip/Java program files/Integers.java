
public class Integers {
	public static void main(String[] arguments) {
	    int c; 
	    for (c = 1; c <= 50; c++) {
	      System.out.println(c);
	    }
	  }
}
