package createstaticproperty;

public class Student {
	   int rollno;  
	   String name;  
	   static String college ="HITS";  //initializing variables
	     
	   Student(int r,String n){  
	   rollno = r;  
	   name = n;  
	   }  
	 void display (){System.out.println(rollno+" "+name+" "+college);}  //printing
	  
	public static void main(String args[]){  
	 Student s1 = new Student(111,"Ravali");  //creating object
	 Student s2 = new Student(222,"Ball");  //creating object
	   
	 s1.display();  //calling object
	 s2.display(); //calling object 
	}  

}
