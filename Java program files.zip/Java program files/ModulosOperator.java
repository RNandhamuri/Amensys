package com.Operators;

public class ModulosOperator {
	public static void main(String[] args) {
        System.out.println("Java Modulus Operator example");
         int i = 50;
         double d = 32;
         System.out.println("i mod 10 = " + i%10);
         System.out.println("d mod 10 = " + d%10);
}
}
