package callingmethodwithreturnandparameter;

public class Student4 {
	int id;  
	   String name;  
	      
	   Student4(int i,String n)//parameterized constructor
	{  
	    id = i;  
	    name = n;  //assigning values
	    }  
	    void display(){
	System.out.println(id+" "+name);}    
	public static void main(String args[]){  
	  Student4 s1 = new Student4(111,"Ravali");  //creation of objects and paasing values
	  Student4 s2 = new Student4(222,"Ball");  
	   s1.display();  //calling method
	   s2.display();  
	  }  

}
