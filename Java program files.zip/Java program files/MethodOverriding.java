package com.Overriding;
class Vehicle{
void run(){
	System.out.println("Vehicle is running");}  
	}  
	class Bike2 extends Vehicle{  // method overriding
	void run()
	{
		System.out.println("Bike is running safely");
		}
	}
public class MethodOverriding {
	 		  
		public static void main(String args[]){  
		Bike2 r = new Bike2();
		Vehicle b = new Vehicle();
		r.run();
		b.run();  
}
}
