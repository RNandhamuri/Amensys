package com.stringbuilderexample;

public class BuilderTest {
	public static void main(String[] args){  
        StringBuilder builder=new StringBuilder("hello");  
        builder.append("java");  
        System.out.println(builder);  
    }  

}
