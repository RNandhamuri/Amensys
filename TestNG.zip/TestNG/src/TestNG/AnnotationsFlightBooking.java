package TestNG;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AnnotationsFlightBooking {
	
@BeforeMethod
public void UseridGeneration()
{
	System.out.println("UseridGeneration");
	
}
@BeforeTest
public void Cookies()
{
	System.out.println("Delete the Cookies before starting the tests");
	
}
@AfterTest
public void Cookiesclose()
{
	System.out.println("Delete Cookies after completing all the tests");
	
}

@Test
public void OpeningBrowser()
{
	System.out.println("Opening Browser");
	
}
@Test
public void FlightBooking()
{
	System.out.println("FlightBooking");
	
}
}
